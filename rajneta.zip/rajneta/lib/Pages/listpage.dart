import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajneta/Pages/ByPosition.dart';
import 'package:rajneta/Pages/bluetoothSlipReportByUser.dart';
import 'package:rajneta/Pages/byAdderss.dart';
import 'package:rajneta/Pages/byAge.dart';
import 'package:rajneta/Pages/byCast.dart';
import 'package:rajneta/Pages/byColorCode.dart';
import 'package:rajneta/Pages/byDead.dart';
import 'package:rajneta/Pages/byGender.dart';
import 'package:rajneta/Pages/byHouseNo.dart';
import 'package:rajneta/Pages/byNewAdderss.dart';
import 'package:rajneta/Pages/byPartNO.dart';
import 'package:rajneta/Pages/bySociety.dart';
import 'package:rajneta/Pages/bySuraname.dart';
import 'package:rajneta/Pages/bySurveyTeam.dart';
import 'package:rajneta/Pages/byTaluka.dart';
import 'package:rajneta/Pages/extraChech1.dart';
import 'package:rajneta/Pages/extraInfo1.dart';
import 'package:rajneta/Pages/extraInfo3.dart';
import 'package:rajneta/Pages/extraInfo4.dart';
import 'package:rajneta/Pages/extraInfo5.dart';
import 'package:rajneta/Pages/mobileNoList.dart';
import 'package:rajneta/Pages/repeated.dart';
import 'package:rajneta/Pages/slipPrintReport.dart';
import 'package:rajneta/Pages/stareVoter.dart';
import 'package:rajneta/Pages/todayBirthday.dart';
import 'package:rajneta/Pages/voted.dart';
import 'package:rajneta/Pages/voterWithoutMobile.dart';
import '../Utils/colors.dart';
import 'ByPersonnel.dart';
import 'alphabeticalList.dart';
import 'byVillage.dart';
import 'byvotingCenter.dart';
import 'demandsList.dart';
import 'extraCheck2.dart';
import 'extraInfo2.dart';

class ListPage extends StatefulWidget {
  final String itemName;
  final String selectedLanguage;

  ListPage({Key? key, required this.itemName, required this.selectedLanguage}) : super(key: key);

  @override
  State<ListPage> createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.backgroundColor,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Container
            Container(
              height: 100,
              decoration: BoxDecoration(
                color: AppColors.secondaryColor,
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () {
                      Navigator.pop(context); // Navigate back on button press
                    },
                  ),
                  SizedBox(width: 10), // Space between icon and text
                  Expanded(
                    child: Text(
                      widget.itemName.tr, // Use .tr for localization
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),

            // Main List with Scroll functionality
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                children: [
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: "alphabetical list".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AlphabeticalList(
                            itemName: 'alphabetical list',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/homelogo.png", width: 30, height: 30),
                    text: "By Village".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByVillageList(
                            itemName: 'By Village',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/partLogo.png", width: 30, height: 30),
                    text: "By Part No".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByPartNo(
                            itemName: 'By Part No',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/locatioLogo.png", width: 30, height: 30),
                    text: "By voiting center".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByVotingCenter(
                            itemName: 'By voiting center',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/persnolLogo.png", width: 30, height: 30),
                    text: "By Personnel".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByPersonnel(
                            itemName: 'By Personnel',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/surnameLogo.png", width: 30, height: 30),
                    text: "By Surname".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BySuraname(
                            itemName: 'By Surname',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/colorLogo.png", width: 30, height: 30),
                    text: "By Colour Code".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByColorCode(
                            itemName: 'By Colour Code',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/MobileLogo.png", width: 30, height: 30),
                    text: "Mobile No List".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MobileNoList(
                            itemName: 'Mobile No List',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),

                  _buildListItem(
                    icon: Image.asset("assets/withoutMobilaLogo.png", width: 30, height: 30),
                    text: "VotercWithout Mobile".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VoterWithoutMobile(
                            itemName: 'VotercWithout Mobile',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/adderssLogo.png", width: 30, height: 30),
                    text: "By Adderss".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByAdderss(
                            itemName: 'By Adderss',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/adderssLogo.png", width: 30, height: 30),
                    text: "By New Adderss".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByNewAdderss(
                            itemName: 'By New Adderss',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/adderssLogo.png", width: 30, height: 30),
                    text: "By Society".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BySociety(
                            itemName: 'By Society',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/genderLogo.png", width: 30, height: 30),
                    text: "By Gender".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByGender(
                            itemName: 'By Gender',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/agelogo.png", width: 30, height: 30),
                    text: "By Age".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByAge(
                            itemName: 'By Age',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/castLogo.png", width: 30, height: 30),
                    text: "By Caste".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByCast(
                            itemName: 'By Caste',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/postionLogo.png", width: 30, height: 30),
                    text: "By Position".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByPosition(
                            itemName: 'By Position',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/deadLogo.png", width: 30, height: 30),
                    text: "By Dead".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByDead(
                            itemName: 'By Dead',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/agelogo.png", width: 30, height: 30),
                    text: "Repeated".tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Repeated(
                            itemName: 'Repeated',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/stareLogo.png", width: 30, height: 30),
                    text: 'Star Voter'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StareVoter(
                            itemName: 'Star Voter',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Ckeck 1'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraCheck1(
                            itemName: 'Extra Ckeck 1',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Ckeck 2'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraCheck2(
                            itemName: 'Extra Ckeck 2',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Info 1'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraInfo1(
                            itemName: 'Extra Info 1',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Info 2'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraInfo2(
                            itemName: 'Extra Info 2',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Info 3'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraInfo3(
                            itemName: 'Extra Info 3',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Info 4'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraInfo4(
                            itemName: 'Extra Info 4',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Extra Info 5'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ExtraInfo5(
                            itemName: 'Extra Info 5',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'By House No'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByHouseNo(
                            itemName: 'By House No',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Demands List'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DemandsList(
                            itemName: 'Demands List',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'voted'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Voted(
                            itemName: 'voted',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'By Survey Team'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BySurveyTeam(
                            itemName: 'By Survey Team',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'By Taluka'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ByTaluka(
                            itemName: 'By Taluka',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Today BirthDay'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TodayBirthDay(
                            itemName: 'Today BirthDay',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Slip Printer Report'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SlipPrinterReport(
                            itemName: 'Slip Printer Report',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                  _buildListItem(
                    icon: Image.asset("assets/AToZ.png", width: 30, height: 30),
                    text: 'Bluetooth Slip Report By User'.tr,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BluetoothSlipReportByUser(
                            itemName: 'Bluetooth Slip Report By User',
                            selectedLanguage: widget.selectedLanguage,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDivider(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget for each list item with GestureDetector for navigation
  Widget _buildListItem({
    required Widget icon, // Change from IconData to Widget
    required String text,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 1.0),
        child: Row(
          children: [
            icon, // Use the passed icon widget directly
            SizedBox(width: 10),
            Text(
              text,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }


  // Divider widget for consistent styling
  Widget _buildDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Divider(
        thickness: 2,
        color: AppColors.secondaryColor,
      ),
    );
  }
}
