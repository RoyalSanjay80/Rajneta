import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rajneta/Pages/voterDetailPage.dart';
import '../Utils/colors.dart';
import 'LocalizationService.dart';


class AlphabeticalList extends StatelessWidget {
  final String itemName;
  final String selectedLanguage;
  final List<Map<String, String>> votersData = [
    {"name": "हरिराव होळकर", "details": "Some data about voter 1"},
    {"name": "जिजाबाई शिंदे", "details": "Some data about voter 2"},
    {"name": "माधवराव पेशवा", "details": "Some data about voter 3"},
    // Add more voter details here
  ];

  AlphabeticalList({Key? key, required this.itemName, required this.selectedLanguage})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Set the locale based on the selected language
    LocalizationService().changeLocale(selectedLanguage);

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        body: Column(
          children: [
            // Custom header with a back button
            Container(
              height: 100,
              decoration: BoxDecoration(
                color: AppColors.secondaryColor,
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () {
                      Navigator.pop(context); // Navigate back on button press
                    },
                  ),
                  SizedBox(width: 10), // Space between icon and text
                  Expanded(
                    child: Text(
                      itemName.tr, // Use .tr for localization
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16), // Space between header and search box
            // Search box with background color
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white, // Background color for the search box
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search Voters', // Localized hint text
                    border: InputBorder.none, // Remove the default border
                    suffixIcon: Icon(Icons.mic, color: AppColors.secondaryColor),
                    contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  ),
                ),
              ),
            ),
            SizedBox(height: 16),

            // List of voters
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.all(8.0),
                itemCount: votersData.length, // Number of items
                itemBuilder: (context, index) {
                  final voter = votersData[index]; // Get each voter data
                  return GestureDetector(
                    onTap: () {
                      // Navigate to the voter detail page when tapped
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VoterDetailPage(
                            voterName: voter['name']!,
                            voterDetails: voter['details']!,
                            selectedLanguage: selectedLanguage,
                          ),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10), // Rounded corners
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3), // Subtle shadow effect
                              spreadRadius: 1,
                              blurRadius: 5,
                              offset: Offset(0, 3), // Position of the shadow
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween, // Align text and icon
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 16.0), // Space around text
                                  child: Text(
                                    voter['name']!,
                                    style: TextStyle(
                                      fontSize: 16, // Font size for text
                                      fontWeight: FontWeight.w500, // Weight of the text
                                    ),
                                  ),
                                ),
                                Icon(
                                  Icons.more_horiz,
                                  color: AppColors.secondaryColor,
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(voter['details']!),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
