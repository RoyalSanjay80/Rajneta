import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Models/allvoterlistModel.dart';
import '../Utils/colors.dart';
import 'voterDetailPage.dart';
import 'package:http/http.dart'as http;

class ItemDetailPage extends StatelessWidget {
  final String itemName;
  final String selectedLanguage;

  const ItemDetailPage({
    Key? key,
    required this.itemName,
    required this.selectedLanguage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final VoterController voterController = Get.put(VoterController());

    // Fetch voters data when the page loads
    voterController.fetchVotersData(selectedLanguage.substring(0, 2).toLowerCase());

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        body: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeader(),
              SizedBox(height: 20),
              _buildSearchBox(voterController),
              _buildVoterList(voterController),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: AppColors.secondaryColor,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
      ),
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Get.back(),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              itemName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBox(VoterController voterController) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: TextField(
          onChanged: (value) {
            if (value.isNotEmpty) {
              voterController.searchVoters(value, selectedLanguage.substring(0, 2).toLowerCase());
            } else {
              voterController.fetchVotersData(selectedLanguage.substring(0, 2).toLowerCase());
            }
          },
          decoration: InputDecoration(
            hintText: 'Search Voters',
            border: InputBorder.none,
            prefixIcon: Icon(Icons.search, color: AppColors.secondaryColor),
            contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          ),
        ),
      ),
    );
  }

  Widget _buildVoterList(VoterController voterController) {
    return Obx(() {
      if (voterController.isLoading.value) {
        return Center(child: CircularProgressIndicator());
      } else if (voterController.errorMessage.isNotEmpty) {
        return Center(child: Text(voterController.errorMessage.value));
      } else if (voterController.voters.isEmpty) {
        return Center(child: Text("No voters found"));
      } else {
        return ListView.builder(
          padding: EdgeInsets.all(8.0),
          shrinkWrap: true,
          itemCount: voterController.voters.length,
          itemBuilder: (context, index) {
            final voter = voterController.voters[index];
            final voterName = "${voter.firstName} ${voter.middleName} ${voter.surname}";
            final voterDetails = voter.id != null ? voter.id.toString() : 'No details available';

            return _buildVoterCard(voter, voterName, voterDetails);
          },
        );
      }
    });
  }

  Widget _buildVoterCard(Voter voter, String voterName, String voterDetails) {
    return GestureDetector(
      onTap: () {
        Get.to(() => VoterDetailPage(
          voterName: voterName,
          voterDetails: voterDetails,
          selectedLanguage: selectedLanguage,
        ));
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.3), spreadRadius: 1, blurRadius: 5, offset: Offset(0, 3))],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(voterName, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                SizedBox(height: 4),
                Text("Voter ID: $voterDetails", style: TextStyle(fontSize: 14, color: Colors.grey)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class VoterController extends GetxController {
  RxList<Voter> voters = <Voter>[].obs;
  RxBool isLoading = true.obs;
  RxString errorMessage = ''.obs;

  // Fetch voter data
  Future<void> fetchVotersData(String langCode) async {
    final apiUrl = "https://rajneta.fusiontechlab.site/api/all-voter-list";
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    if (token == null || token.isEmpty) {
      errorMessage.value = 'Authorization token not found';
      isLoading.value = false;
      return;
    }

    final headers = {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };

    final apiUrlWithLang = "$apiUrl?lang=$langCode";

    try {
      final response = await http.get(Uri.parse(apiUrlWithLang), headers: headers);
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final allVotersList = AllVotersList.fromJson(responseData);
        voters.value = allVotersList.voters ?? [];
      } else {
        errorMessage.value = 'Failed to load voter list';
      }
    } catch (e) {
      errorMessage.value = 'Network Error: $e';
    } finally {
      isLoading.value = false;
    }
  }

  // Search voters based on first name
  Future<void> searchVoters(String query, String langCode) async {
    final apiUrl = "https://rajneta.fusiontechlab.site/api/search-by-first-name";
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');

    if (token == null || token.isEmpty) {
      errorMessage.value = 'Authorization token not found';
      return;
    }

    final headers = {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };

    final apiUrlWithParams = "$apiUrl?lang=$langCode&first_name=$query";

    try {
      final response = await http.get(Uri.parse(apiUrlWithParams), headers: headers);
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final allVotersList = AllVotersList.fromJson(responseData);
        voters.value = allVotersList.voters ?? [];
      } else {
        errorMessage.value = 'Failed to load search results';
      }
    } catch (e) {
      errorMessage.value = 'Search Error: $e';
    }
  }
}
