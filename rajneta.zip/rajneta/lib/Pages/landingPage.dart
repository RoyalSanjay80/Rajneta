import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rajneta/Pages/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Utils/colors.dart';
import 'ItemDetailsPage.dart';
import 'LocalizationService.dart';
import 'package:get/get.dart';

import 'advance Screch.dart';
import 'listpage.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  String selectedLanguage = LocalizationService.langs[0];

  Future<void> logoutUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => Loginpage()), // Replace with your actual login page
    );
  }// Default language

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        body: SingleChildScrollView(
          child: Column(
            children: [
              // AppBar with language selection
              Container(
                height: screenHeight * 0.15,
                decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(30),
                  ),
                ),
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(

                      child: Image.asset(
                        'assets/applogo.png',
                        height: screenHeight * 0.07,
                      ),
                      onTap: logoutUser,
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            Container(
                              height: screenHeight * 0.07,
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: 'search',
                                  filled: true,
                                  fillColor: Colors.white,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30),
                                    borderSide: BorderSide.none,
                                  ),
                                  prefixIcon: Icon(Icons.search, color: Colors.grey),
                                  contentPadding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.mic, color: Colors.grey),
                              onPressed: () {
                                print('Voice input tapped');
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    // Language selection dropdown
                    DropdownButton<String>(
                      dropdownColor: AppColors.secondaryColor,
                      icon: Icon(
                        Icons.language,
                        color: Colors.white,
                      ),
                      underline: SizedBox(),
                      value: selectedLanguage,
                      items: LocalizationService.langs
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(
                            value,
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedLanguage = newValue!;
                        });
                        LocalizationService().changeLocale(selectedLanguage);
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: screenHeight * 0.03),
              // Remaining UI (search images, settings, etc.)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ItemDetailPage(
                              itemName: 'search',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/search_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'search'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Advancescrech(
                              itemName: 'advanced_search',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/advanced-search_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'advanced_search'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ListPage(
                              itemName: 'list',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/lists_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'list'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ItemDetailPage(
                              itemName: 'survey',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/survey_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'survey'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ItemDetailPage(
                              itemName: 'data',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/data_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'data'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        // Navigate to ItemDetailPage on tap
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ItemDetailPage(
                              itemName: 'setting',
                              selectedLanguage: selectedLanguage, // Pass the selected language
                            ),
                          ),
                        );
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Image.asset(
                            "assets/setting_360.png",
                            width: screenWidth * 0.45,
                          ),
                          Positioned(
                            bottom: 10,
                            child: Text(
                              'setting'.tr,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.only(left: 28.0),
                child: Center(
                  child: Text("Shirur - Assembly (Applied 166121 v1)For Support - 9921116541",style: TextStyle(
                      color: AppColors.backgroundColor,
                      fontSize: 14
                  ),),
                ),
              ),
              Container(
                height: screenHeight * 0.10,
                width: screenWidth,// 15% of screen height
                decoration: BoxDecoration(
                  color: AppColors.backgroundColor,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(30), // Round corners for the container
                  ),
                ),
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                child: Column(

                  children: [
                    Text("Rajneta Election Software",style: TextStyle(
                        color: AppColors.secondaryColor
                    ),),
                    Text("( rajnetaeclection.com )"),

                  ],
                ),

              )
              // Continue for other UI elements...
            ],
          ),
        ),
      ),
    );
  }
}
