import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../Utils/colors.dart';
import 'ItemDetailsPage.dart';
import 'LocalizationService.dart';

class Advancescrech extends StatefulWidget {
  final String itemName;
  final String selectedLanguage;

  Advancescrech({super.key, required this.itemName, required this.selectedLanguage});

  @override
  State<Advancescrech> createState() => _AdvancescrechState();
}

class _AdvancescrechState extends State<Advancescrech> {
  final TextEditingController surname = TextEditingController();
  final TextEditingController firstnameController = TextEditingController();
  final TextEditingController middlenameController = TextEditingController();
  final TextEditingController lastnameController = TextEditingController();
  final TextEditingController mobileNumberController = TextEditingController();
  final TextEditingController emailIdController = TextEditingController();
  final TextEditingController Fromage = TextEditingController();
  final TextEditingController toage = TextEditingController();
  final TextEditingController partno = TextEditingController();
  final TextEditingController Voterid = TextEditingController();
  final TextEditingController houseno = TextEditingController();

  @override
  void dispose() {
    firstnameController.dispose();
    middlenameController.dispose();
    lastnameController.dispose();
    mobileNumberController.dispose();
    emailIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    LocalizationService().changeLocale(widget.selectedLanguage);

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        body: Column(
          children: [
            // Header Container
            Container(
              height: 100,
              decoration: BoxDecoration(
                color: AppColors.secondaryColor,
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () {
                      Navigator.pop(context); // Navigate back on button press
                    },
                  ),
                  SizedBox(width: 10), // Space between icon and text
                  Expanded(
                    child: Text(
                      widget.itemName.tr, // Use .tr for localization
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Scrollable content
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0), // Add padding for better layout
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(height: 10),
                      textFormFieldCard(
                          hintText: 'Surname'.tr, controller: surname),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'First Name'.tr, controller: firstnameController),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'Middle Name'.tr, controller: middlenameController),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'From Age'.tr, controller: Fromage),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'To Age'.tr, controller: toage),
                      SizedBox(height: screenSize.height * 0.01),

                      textFormFieldCard(
                          hintText: 'Mobile No'.tr, controller: mobileNumberController),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'Part No'.tr, controller: partno),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'Voter Id'.tr, controller: Voterid),
                      SizedBox(height: screenSize.height * 0.01),
                      textFormFieldCard(
                          hintText: 'House No'.tr, controller: houseno),
                      SizedBox(height: screenSize.height * 0.01),
                      // Save Button
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ItemDetailPage(
                                itemName: 'advanced_search',
                                selectedLanguage: widget.selectedLanguage, // Pass the selected language
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 15), backgroundColor: AppColors.secondaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ), // Button color
                        ),
                        child: Text(
                          'Save'.tr, // Localized text
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                      SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Reusable TextFormField Card widget
  Widget textFormFieldCard({
    required String hintText,
    required TextEditingController controller,
  }) {
    return Card(
      color: Colors.white,
      elevation: 4, // Adds shadow for depth effect
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12), // Rounded corners
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        child: TextFormField(
          controller: controller,
          style: TextStyle(color: Colors.black),
          decoration: InputDecoration(
            labelText: hintText,
            labelStyle: TextStyle(color: Colors.black),
            hintText: "Type your text here".tr,
            hintStyle: TextStyle(color: Colors.black54),
            border: InputBorder.none, // No border to match modern app design
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter some text';
            }
            return null;
          },
        ),
      ),
    );
  }
}
