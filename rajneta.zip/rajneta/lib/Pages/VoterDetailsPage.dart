import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:rajneta/Models/voterdetails.dart';
import 'package:rajneta/Utils/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'LocalizationService.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:share_plus/share_plus.dart'; // Import the share_plus package
import 'package:image_picker/image_picker.dart'; // Import for image picking
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart'as http;
import 'package:pdf/widgets.dart' as pw;// Add this import for the color picker

class Voterdetailspage extends StatefulWidget {
  final String selectedLanguage;
  final String name;
  final String voterid;

  const Voterdetailspage({Key? key, required this.selectedLanguage, required this.name, required this. voterid}) : super(key: key);

  @override
  State<Voterdetailspage> createState() => _VoterdetailspageState();
}

class _VoterdetailspageState extends State<Voterdetailspage> {
  bool matSwitchValue = false; // Switch value
  bool isStarred = false;
  String? mobileNumber; // To manage star color
  Color selectedColor = AppColors.secondaryColor;
  late Future<VotersDetails> _voterDetals;


  @override
  void initState() {
    super.initState();
    LocalizationService().changeLocale(widget.selectedLanguage);
    _voterDetals = _fetchIndividualDetails(int.parse(widget.voterid));
  }
   Future<VotersDetails>_fetchIndividualDetails(int id) async{
     final apiUrl = "https://rajneta.fusiontechlab.site/api/individual-voter-details";
     final prefs = await SharedPreferences.getInstance();
     final token = prefs.getString('auth_token');
     if (token == null || token.isEmpty) {
       throw Exception('Authorization token not found');
     }

     final headers = {
       'Authorization': 'Bearer $token',
       'Content-Type': 'application/json',
     };

     final shortLangCode = widget.selectedLanguage.substring(0, 2).toLowerCase();
     final apiUrlWithParams = "$apiUrl?lang=$shortLangCode&id=$id";

     final response = await http.get(Uri.parse(apiUrlWithParams), headers: headers);
     if (response.statusCode == 200) {
       final responseData = json.decode(response.body);
       return VotersDetails.fromJson(responseData);
     } else {
       throw Exception('Failed to load voter details: ${response.reasonPhrase}');
     }

   }

  @override

  Widget build(BuildContext context) {
    // Get screen width and height
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: screenHeight * 0.02),
        child: SingleChildScrollView(
          child: FutureBuilder<VotersDetails>(
            future: _voterDetals,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData || snapshot.data == null) {
                return Center(child: Text('No voter details available.'));
              }

              final voter = snapshot.data!.voter;

              return voter != null
                  ? Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildVoterDetailCard(voter.firstName ?? "N/A"),
                  _buildDetailContainer("Village".tr, voter.voterAddress?.village ?? "N/A"),
                  _buildDetailContainer("Voter ID".tr, voter.voterId ?? "N/A"),
                  _buildDetailContainer("House No".tr, voter.voterAddress?.houseNo ?? "N/A"),
                  _buildDetailContainer("Address".tr, voter.voterAddress?.society ?? "N/A"),
                  _buildDetailContainer("Booth".tr, voter.voterAddress?.booth ?? "N/A"),
                  // _buildMobileNumberSection(voter.mobile1 ?? "N/A"),
                  _buildCustomRow(matSwitchValue, (newValue) {
                    setState(() {
                      matSwitchValue = newValue;
                    });
                  }),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildElevatedButton("Share", null, () => _shareDetails()),
                      _buildElevatedButton("Print", null, () => _printDetails()),
                      _buildElevatedButton("Call", null, () => _makeCall(voter.mobile1 ?? "")),
                    ],
                  ),
                  SizedBox(height: screenHeight * 0.02),
                  _buildElevatedButton("VOTERS ON SAME ADDRESS", null, () => {}),
                  SizedBox(height: screenHeight * 0.01),
                  _buildElevatedButton("VOTERS ON SAME BOOTH", null, () => {}),
                ],
              )
                  : Center(child: Text('Voter details not available.'));
            },
          ),
        ),
      ),
    );
  }




// Helper method to create an ElevatedButton with icon and label
  ElevatedButton _buildElevatedButton(String label, IconData? icon, VoidCallback onPressed, {String? optionalLabel}) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: icon != null ? Icon(icon) : Container(), // Only show icon if it's provided
      label: Text(label, style: TextStyle(fontSize: 18, color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.secondaryColor,
      ),
    );
  }

  void _makeCall(String phoneNumber) async {
    final phoneNumber = "5874120369";
    if (phoneNumber != null && phoneNumber.isNotEmpty) {
      launch('tel:$phoneNumber');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Phone number is not available')),
      );
    }
  }

  void _shareDetails() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Send Voter Details"),
          content: Text("Select how you want to share:"),
          actions: [
            TextButton(
              onPressed: () {
                // Send via SMS
                _sendSMS();
                Navigator.of(context).pop();
              },
              child: Text("Send SMS"),
            ),
            TextButton(
              onPressed: () {
                // Share via WhatsApp
                _shareWhatsApp();
                Navigator.of(context).pop();
              },
              child: Text("WhatsApp"),
            ),
            TextButton(
              onPressed: () {
                // Share via Email
                _shareEmail();
                Navigator.of(context).pop();
              },
              child: Text("Email"),
            ),
            TextButton(
              onPressed: () {
                // Share from Gallery (image)
                _shareFromGallery();
                Navigator.of(context).pop();
              },
              child: Text("Send from Gallery"),
            ),
          ],
        );
      },
    );
  }

  void _sendSMS() async {
    final String name = "John Doe"; // Replace with actual data
    final String phoneNumber = '5874120369';
    if (phoneNumber.isEmpty || name.isEmpty) {
      print('Phone number or name is null');
      return; // Early exit if data is not valid
    }

    // Construct the message
    String message = 'Voter Name: $name, Voter ID: $name';

    // URL encode the message body
    String encodedMessage = Uri.encodeComponent(message);

    // Launch the SMS app with pre-filled details
    final Uri smsUri = Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': encodedMessage},
    );

    print('Attempting to launch: $smsUri'); // Debugging line

    try {
      // Attempt to launch the SMS app
      if (await canLaunch(smsUri.toString())) {
        await launch(smsUri.toString());
      } else {
        print('Could not launch SMS app');
      }
    } catch (e) {
      print('Error launching SMS app: $e');
    }
  }

  void _shareWhatsApp() {
    Share.share('Check out this voter: ${widget.name}, Voter ID: ${widget.name} via WhatsApp');
  }

  void _shareEmail() {
    Share.share('Check out this voter: ${widget.name}, Voter ID: ${widget.name}', subject: 'Voter Details');
  }

  Future<void> _shareFromGallery() async {
    // Pick an image from the gallery
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      // Share.shareFiles([image.path], text: 'Voter Details: ${widget.name}, ID: ${widget.name}');
      Share.shareXFiles([XFile(image.path)], text: 'Voter Details: ${widget.name}, ID:{widget.id}');
    }
  }


  // Function to print voter details
  void _printDetails() async {
    // Create a PDF document
    final pdf = pw.Document();

    // Add a page to the document
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Center(
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text('Voter Details', style: pw.TextStyle(fontSize: 24)),
                pw.SizedBox(height: 20),
                pw.Text('Name: ${widget.name}', style: pw.TextStyle(fontSize: 18)),
                pw.Text('Voter ID: ${widget.name}', style: pw.TextStyle(fontSize: 18)),
              ],
            ),
          );
        },
      ),
    );
  }

  // Voter Detail Card
  Widget _buildVoterDetailCard(String name) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.backgroundColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.secondaryColor)),
              CircleAvatar(
                backgroundColor: AppColors.secondaryColor,
                child: Icon(Icons.person, color: Colors.white, size: 24),
              ),
            ],
          ),
          SizedBox(height: 16),
          _buildDetailRow("part no".tr, "1"),
          SizedBox(height: 8),
          _buildDetailRow("srn".tr, "1"),
          SizedBox(height: 8),
          _buildDetailRow("age".tr, "35"),
          SizedBox(height: 8),
          _buildDetailRow("gender".tr, "Male"),
        ],
      ),
    );
  }

  // Custom Row for Color Code, Stare, Mat
  Widget _buildCustomRow(bool value, ValueChanged<bool> onChanged) {
    return Container(
      color: AppColors.backgroundColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Color Code with colored container
          GestureDetector(
            onTap: () => _openColorPicker(), // Show color picker when tapped
            child: Row(
              children: [
                Text("Color Code", style: TextStyle(fontSize: 16)),
                SizedBox(width: 8), // Spacing between text and container
                Container(
                  height: 30,
                  width: 50, // Adjust the width as needed
                  decoration: BoxDecoration(
                    color: selectedColor, // Set the selected color
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ],
            ),
          ),
          // Stare with star icon and tap to change color
          GestureDetector(
            onTap: () {
              setState(() {
                isStarred = !isStarred; // Toggle star color
              });
            },
            child: Row(
              children: [
                Text("Stare", style: TextStyle(fontSize: 16)),
                SizedBox(width: 5),
                Icon(
                  Icons.star,
                  color: isStarred ? Colors.orange : Colors.grey, // Yellow if starred, grey otherwise
                ),
              ],
            ),
          ),
          // Mat with Switch
          Row(
            children: [
              Text("Mat", style: TextStyle(fontSize: 16)),
              SizedBox(width: 5),
              Switch(
                value: value,
                onChanged: onChanged, // Pass function to handle switch state
                activeColor: AppColors.secondaryColor,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Detail Container
  Widget _buildDetailContainer(String label, String value) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.backgroundColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [_buildDetailRow(label, value)],
      ),
    );
  }

  // Detail Row
  Widget _buildDetailRow(String label, String value) {
    return Row(
      children: [
        Text("$label:- ", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
        Text(
          value.length > 30 // Adjust this number based on your UI needs
              ? '${value.substring(0, 10)}...' // Show truncated text with ellipsis
              : value, // Show full text if it's short enough
          style: TextStyle(color: Colors.black87),
          overflow: TextOverflow.visible, // Allow overflow to be visible
        ),
      ],
    );
  }

  Widget _buildMobileNumberSection() {
    return GestureDetector(
      onTap: () => _showAddPhoneNumberDialog(),
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          child: Row(
            children: [
              Icon(Icons.phone, color: AppColors.secondaryColor),
              SizedBox(width: 10),
              Text("Mobile: ", style: TextStyle(fontSize: 18)),
              Expanded(
                child: Text(
                  mobileNumber ?? "Tap to add phone number",
                  style: TextStyle(fontSize: 18, color: mobileNumber == null ? Colors.red : Colors.black54),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (mobileNumber != null) Icon(Icons.edit, color: AppColors.secondaryColor),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddPhoneNumberDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Enter your phone number"),
          content: TextField(
            onChanged: (value) {
              mobileNumber = value; // Update mobile number as the user types
            },
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(hintText: "Phone Number"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {}); // Update the state to reflect changes
                Navigator.of(context).pop();
              },
              child: Text("Add"),
            ),
          ],
        );
      },
    );
  }


  void _openColorPicker() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Select Color"),
          content: SingleChildScrollView(
            child: BlockPicker(
              pickerColor: selectedColor, // Current color
              onColorChanged: (Color color) {
                setState(() {
                  selectedColor = color; // Update color on selection
                });
              },
            ),
          ),
          actions: [
            TextButton(
              child: Text("Done"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
