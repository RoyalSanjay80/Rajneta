package com.example.rajneta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
